# Implementation Guide: Restored Composite Bonding Treatment Page

## Overview

This guide provides step-by-step instructions for implementing the restored Composite Bonding Treatment Page with full Champagne Reference Standard theming into your production environment.

---

## Prerequisites

Before beginning implementation, ensure you have the following in your project:

### Required Dependencies

```json
{
  "dependencies": {
    "react": "^18.0.0",
    "next": "^14.0.0"
  }
}
```

### Required Fonts

Add to your HTML `<head>` or Next.js layout:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&family=Lora:ital,wght@0,400;0,500;1,400;1,500&display=swap" rel="stylesheet">
```

---

## Step 1: File Structure Setup

Copy the restored files to your project following this structure:

```
your-project/
├── app/
│   └── preview/
│       └── treatments/
│           └── composite-bonding/
│               └── page.tsx
├── components/
│   ├── brand/
│   │   ├── ThemeManager.tsx
│   │   ├── theme-manager.css
│   │   └── lighting-effects.css
│   ├── preview/
│   │   └── treatments/
│   │       ├── TreatmentPageLayout.tsx
│   │       ├── TreatmentHero.tsx
│   │       ├── treatment-hero.css
│   │       ├── InteractiveOverview.tsx
│   │       ├── interactive-overview.css
│   │       ├── AIPersonalisation.tsx
│   │       ├── ai-personalisation.css
│   │       ├── ClinicianInsight.tsx
│   │       ├── clinician-insight.css
│   │       ├── TestimonialsCarousel.tsx
│   │       ├── testimonials-carousel.css
│   │       ├── TreatmentFAQ.tsx
│   │       ├── treatment-faq.css
│   │       ├── BookingCTA.tsx
│   │       ├── booking-cta.css
│   │       ├── ModelViewer.tsx
│   │       └── GlassModal.tsx
│   └── ai/
│       └── treatment-widgets/
│           ├── AICostEstimator.tsx
│           ├── TreatmentTimePredictor.tsx
│           └── ARSmileTryOn.tsx
└── public/
    └── brand/
        └── waves-bg-1920.webp
```

---

## Step 2: Asset Integration

### Wave Background

1. Copy `waves-bg-1920.webp` to your `/public/brand/` directory
2. Ensure the path in CSS files matches: `url('/brand/waves-bg-1920.webp')`

### Treatment Videos and Posters

Ensure you have the following in `/public/treatments-assets/`:

```
/public/treatments-assets/
├── videos/
│   └── composite-bonding.mp4
└── posters/
    └── composite-bonding.jpg
```

### Team Images (Optional)

If using clinician images, place in `/public/team/`:

```
/public/team/
└── dr-nick-maxwell.jpg
```

---

## Step 3: Theme System Integration

### Global CSS Setup

Add theme variables to your global CSS or root layout:

```css
/* Import in your global.css or layout */
@import '../components/brand/theme-manager.css';
@import '../components/brand/lighting-effects.css';
```

### Layout Integration

Add ThemeManager to your root layout:

```tsx
// app/layout.tsx
import ThemeManager from '@/components/brand/ThemeManager';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <ThemeManager />
        {children}
      </body>
    </html>
  );
}
```

---

## Step 4: Content Customization

### Update Treatment Data

Edit `app/preview/treatments/composite-bonding/page.tsx`:

```tsx
const compositeBondingData: TreatmentPageProps = {
  treatment: {
    title: 'Your Treatment Title',
    description: 'Your description',
    video: '/path/to/your/video.mp4',
    stats: ['Your Stat 1', 'Your Stat 2', 'Your Stat 3'],
  },
  // ... customize other sections
};
```

### Update Clinician Information

```tsx
clinician: {
  quote: 'Your clinician quote',
  name: 'Dr Your Name',
  credentials: 'Your Credentials',
  image: '/team/your-image.jpg',
},
```

### Update Contact Links

Edit `components/preview/treatments/BookingCTA.tsx`:

```tsx
<a href="/your-contact-page" className="cta-button...">
  Book Consultation
</a>

<a href="tel:your-phone-number" className="cta-button...">
  Call Us
</a>
```

---

## Step 5: Testing Checklist

### Visual Testing

- [ ] Light mode displays correctly
- [ ] Dark mode displays correctly
- [ ] Theme transitions are smooth
- [ ] Wave backgrounds are visible
- [ ] Iridescent text animates properly
- [ ] All sections render without layout issues

### Functional Testing

- [ ] Tab navigation works in Interactive Overview
- [ ] AI widgets open modals correctly
- [ ] Testimonials carousel auto-rotates
- [ ] FAQ items expand/collapse
- [ ] CTA buttons link correctly
- [ ] Theme toggle button works

### Responsive Testing

- [ ] Desktop (1920px+) renders correctly
- [ ] Tablet (768px-1024px) renders correctly
- [ ] Mobile (375px-767px) renders correctly
- [ ] All text is readable at all sizes
- [ ] Touch targets are adequate on mobile

### Accessibility Testing

- [ ] Keyboard navigation works
- [ ] Screen reader announces content correctly
- [ ] Focus indicators are visible
- [ ] Color contrast meets WCAG AA standards
- [ ] Reduced motion preference is respected

### Performance Testing

- [ ] Page loads in under 3 seconds
- [ ] Images are optimized
- [ ] No console errors
- [ ] Smooth animations (60fps)
- [ ] Lazy loading works for 3D model

---

## Step 6: SEO Optimization

### Meta Tags

Ensure proper meta tags in `page.tsx`:

```tsx
export const metadata = {
  title: "Your Title | Your Practice Name",
  description: "Your meta description (150-160 characters)",
  openGraph: {
    title: "Your Title",
    description: "Your description",
    images: ['/og-image.jpg'],
  },
};
```

### Structured Data

The FAQ section includes structured data automatically. Verify it's rendering:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [...]
}
</script>
```

---

## Step 7: Performance Optimization

### Image Optimization

Convert images to WebP format:

```bash
# Using cwebp (install via: apt-get install webp)
cwebp -q 80 input.jpg -o output.webp
```

### Code Splitting

The 3D ModelViewer is already lazy-loaded:

```tsx
const ModelViewer = React.lazy(() => import('./ModelViewer'));
```

Consider lazy-loading other heavy components if needed.

### CSS Optimization

Ensure CSS files are minified in production:

```bash
# Using cssnano
npx cssnano input.css output.min.css
```

---

## Step 8: Browser Compatibility

### Tested Browsers

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Polyfills (if supporting older browsers)

Add to your project if needed:

```tsx
// For backdrop-filter support
import 'backdrop-filter-polyfill';
```

---

## Step 9: Deployment

### Build Command

```bash
npm run build
```

### Environment Variables

No environment variables required for this implementation.

### Static Export (if applicable)

```bash
npm run build && npm run export
```

---

## Troubleshooting

### Issue: Wave backgrounds not showing

**Solution**: Verify the image path in CSS matches your public directory structure.

```css
/* Check this path matches your setup */
background-image: url('/brand/waves-bg-1920.webp');
```

### Issue: Theme not switching

**Solution**: Ensure ThemeManager is imported in your root layout and CSS variables are loaded.

### Issue: Fonts not loading

**Solution**: Verify Google Fonts link is in your HTML head or Next.js layout.

### Issue: Animations stuttering

**Solution**: Check for reduced motion preference and ensure GPU acceleration:

```css
transform: translateZ(0);
will-change: transform;
```

### Issue: Modal not closing

**Solution**: Verify GlassModal has proper event handlers and z-index is sufficient.

---

## Maintenance

### Regular Updates

1. **Content**: Review and update treatment information quarterly
2. **Images**: Refresh testimonial photos and team images annually
3. **FAQs**: Add new questions based on patient inquiries
4. **Performance**: Run Lighthouse audits monthly

### Monitoring

Track these metrics:

- Page load time (target: <3s)
- Lighthouse Performance score (target: ≥90)
- Lighthouse Accessibility score (target: ≥98)
- Bounce rate (monitor for UX issues)
- Conversion rate (booking button clicks)

---

## Support

For questions or issues with implementation:

1. Review the `RESTORATION-COMPLETE.md` documentation
2. Check the preview HTML file for reference
3. Examine the Technology Page for Champagne Standard examples
4. Test in isolation before integrating into main project

---

## Version History

- **v1.0** (2025-10-14): Initial restored version with full Champagne Reference Standard

---

**Implementation Time Estimate**: 2-4 hours  
**Difficulty Level**: Intermediate  
**Maintenance Level**: Low

---

*This implementation guide ensures a smooth integration of the restored Composite Bonding Treatment Page into your production environment while maintaining all Champagne Reference Standard features.*

