
import React from 'react';
import TreatmentPageLayout, { TreatmentPageProps } from '@/components/preview/treatments/TreatmentPageLayout';

export const metadata = {
  title: "Composite Bonding in Shoreham-by-Sea | St Mary's House Dental Care",
  description: "Same-day composite bonding crafted with 3D precision to perfect your smile. Non-invasive, affordable, and completed in a single visit at our coastal practice.",
};

const compositeBondingData: TreatmentPageProps = {
  treatment: {
    title: 'Composite Bonding',
    description: 'Same-day composite bonding crafted with 3D precision to perfect your smile',
    video: '/treatments-assets/videos/composite-bonding.mp4',
    stats: ['★★★★★ Google Reviews', '3D-Planned', 'Finance Available'],
  },
  overview: {
    tabs: [
      { 
        title: 'What is it?', 
        content: (
          <div>
            <p>Composite bonding is a non-invasive cosmetic treatment where a tooth-coloured composite resin is applied to your teeth to improve their shape, size, and colour. It's perfect for fixing chips, gaps, and discolouration.</p>
            <p className="mt-4">The composite material is carefully selected to match your natural tooth colour, ensuring a seamless blend with your existing smile. This versatile treatment can address multiple aesthetic concerns in a single visit, making it one of the most popular cosmetic dental procedures.</p>
            <p className="mt-4">Unlike veneers or crowns, composite bonding preserves your natural tooth structure, as it requires minimal to no removal of enamel. This makes it an excellent choice for patients who want to enhance their smile while maintaining the integrity of their natural teeth.</p>
          </div>
        )
      },
      { 
        title: 'How it works', 
        content: (
          <div>
            <p>The process is simple and usually completed in one visit. We match the resin to your natural tooth colour, apply it, and then shape and polish it to achieve a seamless, natural-looking result.</p>
            <p className="mt-4">First, we prepare the tooth surface by gently etching it to create a better bond. Then, a conditioning liquid is applied to help the bonding material adhere. The composite resin is carefully applied in layers, with each layer being hardened using a special curing light.</p>
            <p className="mt-4">Once the desired shape and thickness is achieved, we meticulously sculpt and polish the bonding to match the sheen of your natural teeth. The entire process typically takes 30-60 minutes per tooth, depending on the complexity of the work required.</p>
            <p className="mt-4">Our digital planning system allows us to show you a preview of your new smile before we begin, ensuring you're completely happy with the planned outcome.</p>
          </div>
        )
      },
      { 
        title: 'Results', 
        content: (
          <div>
            <p>You can expect a beautifully enhanced smile that looks and feels natural. The results are immediate, and with proper care, can last for many years.</p>
            <p className="mt-4">Composite bonding can dramatically improve the appearance of your teeth, correcting issues such as chips, cracks, gaps, discolouration, and minor misalignments. The material is carefully colour-matched and shaped to blend seamlessly with your natural teeth.</p>
            <p className="mt-4">Most patients are thrilled with the immediate transformation. You'll leave our practice the same day with a refreshed, confident smile. The bonding material is strong and durable, designed to withstand normal biting and chewing forces.</p>
            <p className="mt-4">With proper maintenance, including regular dental check-ups and good oral hygiene, composite bonding can last 5-7 years or longer. The material may need minor touch-ups over time, but these are quick and straightforward procedures.</p>
          </div>
        )
      },
      { 
        title: 'Aftercare', 
        content: (
          <div>
            <p>To maintain your new smile, it's important to practice good oral hygiene and avoid staining foods and drinks for the first 48 hours. Regular check-ups will ensure your bonding stays in top condition.</p>
            <p className="mt-4">Brush your teeth twice daily with a soft-bristled toothbrush and fluoride toothpaste. Floss daily to remove plaque and food particles from between your teeth and around the bonding. Avoid biting on hard objects such as ice, pens, or fingernails, as this can chip the composite material.</p>
            <p className="mt-4">While composite bonding is stain-resistant, it's not completely stain-proof. Limit consumption of highly pigmented foods and beverages such as coffee, tea, red wine, and berries, especially in the first 48 hours after treatment when the material is most susceptible to staining.</p>
            <p className="mt-4">If you grind your teeth at night, we may recommend a custom night guard to protect your bonding. Regular professional cleanings every six months will help maintain the appearance and longevity of your composite bonding.</p>
            <p className="mt-4">Contact us immediately if you notice any chips, cracks, or rough edges on your bonding. Minor repairs can often be completed quickly and easily in a single visit.</p>
          </div>
        )
      },
    ],
  },
  clinician: {
    quote: 'Artistry in every millimetre. Composite bonding is where science meets aesthetics, allowing us to transform smiles with precision and care.',
    name: 'Dr Nick Maxwell',
    credentials: 'BDS (Hons), MJDF RCS (Eng)',
    image: '/team/dr-nick-maxwell.jpg',
  },
  testimonials: [
    { 
      name: 'Jane D.', 
      location: 'Shoreham-by-Sea',
      rating: 5,
      text: 'My teeth look amazing! The composite bonding was so quick and painless. I walked in feeling self-conscious about my chipped front tooth and walked out with a perfect smile. Dr Maxwell and his team were incredibly professional and made me feel completely at ease throughout the entire process.' 
    },
    { 
      name: 'John S.', 
      location: 'Brighton',
      rating: 5,
      text: 'I can't believe the difference. A fantastic result from a very professional team. I had bonding on four front teeth to close gaps and the result is absolutely natural-looking. Friends have commented on how great my smile looks but can't quite put their finger on what's changed!' 
    },
    { 
      name: 'Sarah M.', 
      location: 'Worthing',
      rating: 5,
      text: 'After years of hiding my smile due to discoloured teeth, composite bonding has given me my confidence back. The treatment was completely painless and done in just one appointment. The team took the time to match the colour perfectly, and I couldn't be happier with the results.' 
    },
    { 
      name: 'Michael P.', 
      location: 'Lancing',
      rating: 5,
      text: 'Exceptional service from start to finish. The digital preview of my new smile before treatment was brilliant – I knew exactly what to expect. The bonding looks so natural that even my dentist from my previous practice was impressed when I showed him!' 
    },
  ],
  faqs: [
    { 
      question: 'Is composite bonding painful?', 
      answer: 'Not at all. The procedure is non-invasive and typically requires no anaesthetic. We gently prepare the tooth surface, but this doesn't cause discomfort. Most patients find the treatment completely painless and relaxing.' 
    },
    { 
      question: 'How long does it last?', 
      answer: 'With good care, composite bonding can last from 5 to 7 years, and sometimes longer. The longevity depends on factors such as your oral hygiene habits, diet, and whether you grind your teeth. Regular check-ups and professional cleanings will help maximize the lifespan of your bonding.' 
    },
    { 
      question: 'Can it be whitened?', 
      answer: 'The composite material does not respond to whitening treatments, so we recommend whitening your teeth before the bonding procedure. This allows us to match the bonding to your newly whitened shade, ensuring a uniform, bright smile.' 
    },
    { 
      question: 'How much does it cost?', 
      answer: 'The cost varies depending on the extent of the treatment and the number of teeth involved. Typically, composite bonding ranges from £200-£400 per tooth. We offer flexible finance options to make treatment more accessible, with plans starting from as little as £20 per month. A detailed quote will be provided during your consultation.' 
    },
    { 
      question: 'Who is it for?', 
      answer: 'Composite bonding is ideal for anyone looking to improve their smile by fixing minor imperfections such as chips, gaps, discolouration, or slightly misshapen teeth. It's particularly suitable for patients who want a conservative, non-invasive treatment that preserves their natural tooth structure.' 
    },
    { 
      question: 'How long does the treatment take?', 
      answer: 'Most composite bonding treatments can be completed in a single visit lasting 1-2 hours, depending on the number of teeth being treated. Each tooth typically takes 30-60 minutes to complete. You'll leave the same day with your new smile – no temporary restorations or multiple appointments required.' 
    },
    { 
      question: 'What's the difference between bonding and veneers?', 
      answer: 'Composite bonding is applied directly to your tooth and sculpted in place, while veneers are thin shells that are fabricated in a lab and then bonded to your teeth. Bonding is more conservative, requires less tooth preparation, and can usually be completed in one visit. Veneers are more durable and stain-resistant but require more tooth reduction and multiple appointments.' 
    },
    { 
      question: 'Will my bonding stain?', 
      answer: 'Composite bonding is stain-resistant but not completely stain-proof. With proper care and by avoiding excessive consumption of staining foods and drinks (coffee, tea, red wine, curry), your bonding should maintain its appearance for many years. Professional cleanings every six months will help keep your bonding looking its best.' 
    },
  ],
};

export default function CompositeBondingPage() {
  return <TreatmentPageLayout {...compositeBondingData} />;
}

