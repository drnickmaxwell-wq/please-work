
import React from 'react';

export default function AICostEstimator() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>AI Cost Estimator</h2>
      <p className="mb-4" style={{ fontFamily: 'Lora, serif' }}>This is a placeholder for the AI Cost Estimator. It will integrate with Tabeo to provide financing options.</p>
      <div className="p-8 bg-gray-100 rounded-lg text-center">
        <p className="text-3xl font-bold text-[#C2185B]">£1,500 - £3,000</p>
        <p className="text-sm text-gray-600">Estimated Cost</p>
      </div>
    </div>
  );
}

