
import React from 'react';

export default function TreatmentTimePredictor() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>Treatment Time Predictor</h2>
      <p className="mb-4" style={{ fontFamily: 'Lora, serif' }}>This is a placeholder for the Treatment Time Predictor. It will use AI to estimate the treatment duration.</p>
      <div className="p-8 bg-gray-100 rounded-lg text-center">
        <p className="text-3xl font-bold text-[#40C4B4]">2 - 3 Appointments</p>
        <p className="text-sm text-gray-600">Estimated Duration</p>
      </div>
    </div>
  );
}

