'use client';

import React, { useEffect, useState } from 'react';
import '../../../brand/lighting-effects.css';
import './treatment-hero.css';

interface TreatmentHeroProps {
  title: string;
  description?: string;
  videoSrc: string;
  stats: string[];
}

export default function TreatmentHero({ title, description, videoSrc, stats }: TreatmentHeroProps) {
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  return (
    <section className="treatment-hero">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      {/* Particle Shimmer Field */}
      {!reducedMotion && (
        <div className="particle-shimmer-container" aria-hidden="true">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="shimmer-particle" />
          ))}
        </div>
      )}

      {/* Main Content Container */}
      <div className="hero-content-wrapper">
        <div className="hero-video-container subsurface-glow card-reflection">
          {/* Video Element */}
          {!reducedMotion ? (
            <video
              className="hero-video"
              poster={`/treatments-assets/posters/${videoSrc.split('/').pop()?.replace('.mp4', '.jpg')}`}
              autoPlay
              muted
              playsInline
              loop
            >
              <source src={videoSrc} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <div 
              className="hero-video-poster"
              style={{ 
                backgroundImage: `url(/treatments-assets/posters/${videoSrc.split('/').pop()?.replace('.mp4', '.jpg')})` 
              }}
              role="img"
              aria-label={`${title} treatment preview`}
            />
          )}

          {/* Text Overlay */}
          <div className="hero-overlay">
            <h1 className="hero-title iridescent-text depth-bloom">
              {title}
            </h1>
            
            {description && (
              <p className="hero-description">
                {description}
              </p>
            )}

            {/* Glass Stat Badge */}
            <div className="hero-stats-badge subsurface-glow">
              {stats.map((stat, index) => (
                <React.Fragment key={index}>
                  <span className="stat-item">{stat}</span>
                  {index < stats.length - 1 && <span className="stat-divider">•</span>}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

