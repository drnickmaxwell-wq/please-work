"use client";
import React, { useState, useEffect, Suspense } from 'react';
import '../../../brand/lighting-effects.css';
import './interactive-overview.css';

// Lazy load the 3D viewer to improve initial page load
const ModelViewer = React.lazy(() => import('./ModelViewer'));

interface InteractiveOverviewProps {
  tabs: { title: string; content: React.ReactNode }[];
}

export default function InteractiveOverview({ tabs }: InteractiveOverviewProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  return (
    <section className="interactive-overview">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      {/* Particle Shimmer Field */}
      {!reducedMotion && (
        <div className="particle-shimmer-container" aria-hidden="true">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="shimmer-particle" />
          ))}
        </div>
      )}
      
      <div className="overview-content-wrapper">
        {/* 3D Viewer Side */}
        <div className="viewer-container subsurface-glow card-reflection">
          <Suspense fallback={
            <div className="viewer-loading">
              <p>Loading 3D Model...</p>
            </div>
          }>
            <ModelViewer />
          </Suspense>
        </div>

        {/* Content Side */}
        <div className="tabs-container">
          {/* Tab Navigation */}
          <div className="tabs-navigation">
            {tabs.map((tab, index) => (
              <button
                key={index}
                onClick={() => setActiveTab(index)}
                className={`tab-button ${activeTab === index ? 'tab-active' : ''}`}
                aria-selected={activeTab === index}
                role="tab"
              >
                {tab.title}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="tab-content">
            {tabs[activeTab].content}
          </div>
        </div>
      </div>
    </section>
  );
}

