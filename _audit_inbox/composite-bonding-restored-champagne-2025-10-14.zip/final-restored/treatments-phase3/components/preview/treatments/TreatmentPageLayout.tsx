
'use client';

import React from 'react';
import ThemeManager from '@/components/brand/ThemeManager';
import TreatmentHero from './TreatmentHero';
import InteractiveOverview from './InteractiveOverview';
import AIPersonalisation from './AIPersonalisation';
import ClinicianInsight from './ClinicianInsight';
import TestimonialsCarousel from './TestimonialsCarousel';
import TreatmentFAQ from './TreatmentFAQ';
import BookingCTA from './BookingCTA';

export interface TreatmentPageProps {
  treatment: {
    title: string;
    description: string;
    video: string;
    stats: string[];
  };
  overview: {
    tabs: { title: string; content: React.ReactNode }[];
  };
  clinician: {
    quote: string;
    name: string;
    credentials?: string;
    image?: string;
  };
  testimonials: {
    name: string;
    location?: string;
    rating?: number;
    text: string;
  }[];
  faqs: { question: string; answer: string }[];
}

export default function TreatmentPageLayout({ 
  treatment, 
  overview, 
  clinician, 
  testimonials, 
  faqs 
}: TreatmentPageProps) {
  return (
    <>
      <ThemeManager />
      <main className="theme-lux bg-[var(--background)] text-[var(--foreground)] transition-colors duration-1000">
        {/* Section 1: Hero */}
        <TreatmentHero 
          title={treatment.title} 
          description={treatment.description}
          videoSrc={treatment.video}
          stats={treatment.stats}
        />
        
        {/* Section 2: Interactive Overview with Tabs */}
        <InteractiveOverview tabs={overview.tabs} />
        
        {/* Section 3: AI Personalisation */}
        <AIPersonalisation />
        
        {/* Section 4: Clinician Insight */}
        <ClinicianInsight 
          quote={clinician.quote} 
          name={clinician.name}
          credentials={clinician.credentials}
          image={clinician.image}
        />
        
        {/* Section 5: Testimonials Carousel */}
        <TestimonialsCarousel testimonials={testimonials} />
        
        {/* Section 6: FAQ */}
        <TreatmentFAQ faqs={faqs} />
        
        {/* Section 7: Booking CTA */}
        <BookingCTA />
      </main>
    </>
  );
}

