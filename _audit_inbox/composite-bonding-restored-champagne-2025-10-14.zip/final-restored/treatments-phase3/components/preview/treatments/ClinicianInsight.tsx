'use client';

import React from 'react';
import '../../../brand/lighting-effects.css';
import './clinician-insight.css';

interface ClinicianInsightProps {
  quote: string;
  name: string;
  credentials?: string;
  image?: string;
}

export default function ClinicianInsight({ quote, name, credentials, image }: ClinicianInsightProps) {
  return (
    <section className="clinician-insight">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      <div className="insight-content-wrapper">
        {/* Clinician Image (if provided) */}
        {image && (
          <div className="clinician-image-container subsurface-glow">
            <img 
              src={image} 
              alt={name}
              className="clinician-image"
            />
          </div>
        )}
        
        {/* Quote Container */}
        <div className="quote-container">
          {/* Gold Accent Lines */}
          <div className="quote-accent quote-accent-top" aria-hidden="true" />
          
          <blockquote className="clinician-quote">
            <span className="quote-mark">"</span>
            {quote}
            <span className="quote-mark">"</span>
          </blockquote>
          
          <div className="quote-accent quote-accent-bottom" aria-hidden="true" />
          
          {/* Clinician Attribution */}
          <div className="clinician-attribution">
            <p className="clinician-name">— {name}</p>
            {credentials && (
              <p className="clinician-credentials">{credentials}</p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

