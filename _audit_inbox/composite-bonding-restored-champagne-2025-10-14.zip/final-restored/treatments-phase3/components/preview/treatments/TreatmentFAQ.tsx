'use client';

import React, { useState } from 'react';
import '../../../brand/lighting-effects.css';
import './treatment-faq.css';

interface TreatmentFAQProps {
  faqs: { question: string; answer: string }[];
}

export default function TreatmentFAQ({ faqs }: TreatmentFAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="treatment-faq">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      <div className="faq-content-wrapper">
        {/* Section Header */}
        <div className="faq-header">
          <h2 className="faq-title iridescent-text">
            Your Questions Answered
          </h2>
          <p className="faq-subtitle">
            Everything you need to know about the treatment. Can't find the answer you're looking for? Please contact our friendly team.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="faq-items">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`faq-item subsurface-glow ${openIndex === index ? 'faq-item-open' : ''}`}
            >
              <button
                className="faq-question"
                onClick={() => toggleFAQ(index)}
                aria-expanded={openIndex === index}
              >
                <h3 className="question-text">{faq.question}</h3>
                <div className="question-icon">
                  <svg 
                    className="icon-svg" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M19 9l-7 7-7-7" 
                    />
                  </svg>
                </div>
              </button>
              
              <div className="faq-answer">
                <div className="answer-content">
                  <p>{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Structured Data for SEO */}
      <script 
        type="application/ld+json" 
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })
        }} 
      />
    </section>
  );
}

