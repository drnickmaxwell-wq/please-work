'use client';

import React from 'react';
import '../../../brand/lighting-effects.css';
import './booking-cta.css';

export default function BookingCTA() {
  return (
    <section className="booking-cta">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      <div className="cta-content-wrapper">
        {/* CTA Heading */}
        <h2 className="cta-title iridescent-text depth-bloom">
          Begin Your Smile Transformation
        </h2>
        
        {/* CTA Description */}
        <p className="cta-description">
          Your journey to a perfect smile starts with a conversation. Book your consultation today and discover how we can help you achieve the smile you've always wanted. Our experienced team is ready to guide you through every step of the process.
        </p>
        
        {/* CTA Buttons */}
        <div className="cta-buttons">
          <a
            href="/contact"
            className="cta-button cta-button-primary cta-hover-lift subsurface-glow"
          >
            <span className="button-text">Book Consultation</span>
            <span className="button-icon" aria-hidden="true">→</span>
          </a>
          
          <a
            href="tel:01273455123"
            className="cta-button cta-button-secondary cta-hover-lift subsurface-glow"
          >
            <span className="button-text">Call Us</span>
            <span className="button-icon" aria-hidden="true">📞</span>
          </a>
        </div>
        
        {/* Additional Info */}
        <div className="cta-info">
          <div className="info-item">
            <span className="info-icon" aria-hidden="true">✓</span>
            <span className="info-text">Free Consultation</span>
          </div>
          <div className="info-item">
            <span className="info-icon" aria-hidden="true">✓</span>
            <span className="info-text">Flexible Finance Available</span>
          </div>
          <div className="info-item">
            <span className="info-icon" aria-hidden="true">✓</span>
            <span className="info-text">Same-Day Appointments</span>
          </div>
        </div>
      </div>
    </section>
  );
}

