'use client';

import React, { useState } from 'react';
import GlassModal from './GlassModal';
import AICostEstimator from '../../ai/treatment-widgets/AICostEstimator';
import TreatmentTimePredictor from '../../ai/treatment-widgets/TreatmentTimePredictor';
import ARSmileTryOn from '../../ai/treatment-widgets/ARSmileTryOn';
import '../../../brand/lighting-effects.css';
import './ai-personalisation.css';

const widgets = [
  { 
    title: 'AI Cost Estimator',
    description: 'Get a personalized cost estimate for your treatment based on your specific needs and circumstances.',
    icon: '💰',
    component: <AICostEstimator />
  },
  {
    title: 'Treatment Time Predictor',
    description: 'Estimate the duration of your treatment from start to finish, including all appointments and recovery time.',
    icon: '⏱️',
    component: <TreatmentTimePredictor />
  },
  {
    title: 'AR Smile Try-On',
    description: 'Visualize your new smile with our augmented reality tool before committing to treatment.',
    icon: '😊',
    component: <ARSmileTryOn />
  }
];

export default function AIPersonalisation() {
  const [modalContent, setModalContent] = useState<React.ReactNode | null>(null);

  const openModal = (content: React.ReactNode) => {
    setModalContent(content);
  };

  const closeModal = () => {
    setModalContent(null);
  };

  return (
    <section className="ai-personalisation">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      <div className="ai-content-wrapper">
        {/* Section Header */}
        <div className="ai-header">
          <h2 className="ai-title iridescent-text">
            Personalize Your Journey
          </h2>
          <p className="ai-subtitle">
            Use our AI-powered tools to get a clearer picture of your treatment plan, costs, and expected outcomes.
          </p>
        </div>

        {/* Widget Cards */}
        <div className="ai-widgets-grid">
          {widgets.map((widget, index) => (
            <div 
              key={index} 
              className="ai-widget-card subsurface-glow card-reflection depth-tilt"
              onClick={() => openModal(widget.component)}
              role="button"
              tabIndex={0}
              onKeyPress={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  openModal(widget.component);
                }
              }}
            >
              <div className="widget-icon" aria-hidden="true">
                {widget.icon}
              </div>
              <h3 className="widget-title">
                {widget.title}
              </h3>
              <p className="widget-description">
                {widget.description}
              </p>
              <div className="widget-cta">
                Open Tool
              </div>
            </div>
          ))}
        </div>
      </div>

      {modalContent && (
        <GlassModal onClose={closeModal}>
          {modalContent}
        </GlassModal>
      )}
    </section>
  );
}

