'use client';

import React, { useState, useEffect } from 'react';
import '../../../brand/lighting-effects.css';
import './testimonials-carousel.css';

interface Testimonial {
  name: string;
  location?: string;
  rating?: number;
  text: string;
}

interface TestimonialsCarouselProps {
  testimonials: Testimonial[];
}

export default function TestimonialsCarousel({ testimonials }: TestimonialsCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (reducedMotion || testimonials.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000); // 6 seconds per testimonial
    return () => clearInterval(interval);
  }, [reducedMotion, testimonials.length]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  return (
    <section className="testimonials-carousel">
      {/* Wave Background Layer */}
      <div className="wave-background" aria-hidden="true" />
      
      {/* Film Grain Overlay */}
      <div className="film-grain-overlay" aria-hidden="true" />
      
      <div className="testimonials-content-wrapper">
        {/* Section Header */}
        <h2 className="testimonials-title iridescent-text">
          Patient Stories
        </h2>
        
        {/* Carousel Container */}
        <div className="carousel-container">
          {/* Navigation Buttons */}
          {testimonials.length > 1 && (
            <>
              <button 
                className="carousel-nav carousel-nav-prev"
                onClick={goToPrevious}
                aria-label="Previous testimonial"
              >
                ‹
              </button>
              <button 
                className="carousel-nav carousel-nav-next"
                onClick={goToNext}
                aria-label="Next testimonial"
              >
                ›
              </button>
            </>
          )}
          
          {/* Testimonial Slides */}
          <div className="carousel-slides">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index} 
                className={`testimonial-slide ${index === currentIndex ? 'slide-active' : ''}`}
              >
                {/* Star Rating */}
                <div className="testimonial-rating" aria-label={`${testimonial.rating || 5} star rating`}>
                  {[...Array(testimonial.rating || 5)].map((_, i) => (
                    <svg 
                      key={i} 
                      className="star-icon" 
                      fill="currentColor" 
                      viewBox="0 0 20 20"
                      aria-hidden="true"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg>
                  ))}
                </div>
                
                {/* Testimonial Text */}
                <blockquote className="testimonial-text">
                  <span className="quote-mark">"</span>
                  {testimonial.text}
                  <span className="quote-mark">"</span>
                </blockquote>
                
                {/* Testimonial Attribution */}
                <div className="testimonial-attribution">
                  <p className="testimonial-name">{testimonial.name}</p>
                  {testimonial.location && (
                    <p className="testimonial-location">{testimonial.location}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Carousel Indicators */}
          {testimonials.length > 1 && (
            <div className="carousel-indicators">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`indicator ${index === currentIndex ? 'indicator-active' : ''}`}
                  onClick={() => goToSlide(index)}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

