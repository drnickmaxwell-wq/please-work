"use client";
import React from 'react';

export default function ModelViewer() {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gray-200 rounded-2xl">
      <p className="text-gray-500">3D Model Viewer Placeholder</p>
    </div>
  );
}

